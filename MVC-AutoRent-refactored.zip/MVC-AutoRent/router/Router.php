<?php
declare(strict_types=1);

class Router
{
    /** @var array<string, array<string, callable>> */
    private array $routes = [];

    /**
     * Enregistre une route GET.
     */
    public function get(string $path, callable $handler): void
    {
        $this->routes['GET'][$path] = $handler;
    }

    /**
     * Enregistre une route POST.
     */
    public function post(string $path, callable $handler): void
    {
        $this->routes['POST'][$path] = $handler;
    }

    /**
     * Résout et exécute la route correspondant à la requête courante.
     */
    public function dispatch(): void
    {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

        // Normalise l'URI : supprime le query string et le slash final
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $uri = rtrim($uri, '/') ?: '/';

        if (isset($this->routes[$method][$uri])) {
            call_user_func($this->routes[$method][$uri]);
            return;
        }

        // Route introuvable → 404
        http_response_code(404);
        echo '<h1>404 — Page introuvable</h1>';
    }
}
