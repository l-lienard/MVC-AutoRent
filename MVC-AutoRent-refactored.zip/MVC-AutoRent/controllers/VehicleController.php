<?php
declare(strict_types=1);

require_once __DIR__ . '/../models/VehicleModel.php';

class VehicleController
{
    private VehicleModel $model;

    public function __construct()
    {
        $this->model = new VehicleModel();
    }

    /**
     * Action principale : affiche la liste des véhicules avec filtre optionnel.
     */
    public function index(): void
    {
        $typeSelectionne = $this->getTypeFilter();
        $vehicules       = $this->model->getAllVehicles();

        // Application du filtre côté contrôleur
        if ($typeSelectionne !== '') {
            $vehicules = array_filter(
                $vehicules,
                fn(array $v): bool => ($v['Type'] ?? '') === $typeSelectionne
            );
        }

        $this->render('index', [
            'vehicules'       => $vehicules,
            'typeSelectionne' => $typeSelectionne,
        ]);
    }

    /**
     * Action POST : importe un fichier CSV uploadé.
     */
    public function importCsv(): void
    {
        if (!isset($_FILES['file_csv']) || $_FILES['file_csv']['error'] !== UPLOAD_ERR_OK) {
            $this->redirectHome(['error' => 'upload_failed']);
            return;
        }

        $file = $_FILES['file_csv'];

        // Validation de l'extension
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if ($extension !== 'csv') {
            $this->redirectHome(['error' => 'invalid_type']);
            return;
        }

        $success = $this->model->importVehicles($file['tmp_name']);

        if ($success) {
            $this->redirectHome(['success' => '1']);
        } else {
            $this->redirectHome(['error' => 'import_failed']);
        }
    }

    // -------------------------------------------------------------------------
    // Méthodes privées utilitaires
    // -------------------------------------------------------------------------

    /**
     * Récupère et assainit le filtre de type depuis $_GET.
     */
    private function getTypeFilter(): string
    {
        $allowed = ['', 'Voiture', 'Moto', 'CampingCar'];
        $type    = trim($_GET['type_voiture'] ?? '');

        return in_array($type, $allowed, true) ? $type : '';
    }

    /**
     * Charge le fichier de vue en lui injectant les variables passées.
     *
     * @param string               $view      Nom de la vue (sans .php)
     * @param array<string, mixed> $variables Variables à exposer dans la vue
     */
    private function render(string $view, array $variables = []): void
    {
        extract($variables, EXTR_SKIP);
        $viewPath = __DIR__ . '/../views/' . $view . '.php';

        if (!file_exists($viewPath)) {
            http_response_code(500);
            echo "Vue introuvable : $view";
            return;
        }

        require $viewPath;
    }

    /**
     * Redirige vers la page d'accueil avec des paramètres GET optionnels.
     *
     * @param array<string, string> $params
     */
    private function redirectHome(array $params = []): void
    {
        $query = $params ? '?' . http_build_query($params) : '';
        header('Location: /' . $query);
        exit;
    }
}
