<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AutoRent - Véhicules</title>
    <link rel="stylesheet" href="public/lobby.css">
</head>

<body>
<?php include __DIR__ . '/navbar.php'; ?>

<!-- Hero -->
<section class="section-hero">
    <div class="texte-hero">
        <h1>AutoRent — Partez où vous voulez,<br><span>quand vous voulez</span></h1>
        <p>Performance · Élégance · Confort</p>
        <a href="#vehicules" class="bouton-voir-vehicules">Voir les véhicules</a>
    </div>
</section>

<!-- Import CSV -->
<section class="section-import" style="padding: 20px; text-align: center; background: #f9f9f9; border-bottom: 1px solid #ddd;">
    <form action="/" method="POST" enctype="multipart/form-data">
        <label style="font-weight: bold; margin-right: 10px;">Ajouter des véhicules via CSV :</label>
        <input type="file" name="file_csv" accept=".csv" required>
        <button type="submit" name="submit_import" class="bouton-filtrer">Ajouter à la liste</button>
    </form>

    <?php if (isset($_GET['success'])): ?>
        <p style="color: green;">Fichier ajouté avec succès !</p>
    <?php elseif (isset($_GET['error'])): ?>
        <p style="color: red;">
            <?php
            $messages = [
                'upload_failed'  => "Erreur lors de l'upload du fichier.",
                'invalid_type'   => "Le fichier doit être au format CSV.",
                'import_failed'  => "L'import a échoué. Vérifiez le format du fichier.",
            ];
            echo htmlspecialchars($messages[$_GET['error']] ?? 'Une erreur est survenue.');
            ?>
        </p>
    <?php endif; ?>
</section>

<!-- Liste des véhicules -->
<section class="section-liste-voitures">
    <h2 id="vehicules" class="titre-section">Liste des véhicules</h2>
    <p class="sous-titre-section">Filtrez par type de véhicule pour trouver votre bonheur</p>

    <form class="formulaire-filtre" method="GET" action="/">
        <select class="liste-deroulante-type" name="type_voiture">
            <option value="">-- Tous les types --</option>
            <option value="Voiture"    <?php if ($typeSelectionne === 'Voiture')    echo 'selected'; ?>>Voiture</option>
            <option value="Moto"       <?php if ($typeSelectionne === 'Moto')       echo 'selected'; ?>>Moto</option>
            <option value="CampingCar" <?php if ($typeSelectionne === 'CampingCar') echo 'selected'; ?>>Camping-Car</option>
        </select>
        <button class="bouton-filtrer" type="submit">Filtrer</button>
    </form>

    <div class="grille-voitures">
        <?php foreach ($vehicules as $vehicule): ?>
            <div class="carte-voiture">

                <div class="entete-carte">
                    <?php
                    $etat        = $vehicule['Etat'] ?? '';
                    $badgeClass  = match ($etat) {
                        'Disponible' => 'badge-disponible',
                        'Loué'       => 'badge-loue',
                        default      => 'badge-reparation',
                    };
                    ?>
                    <span class="<?= htmlspecialchars($badgeClass) ?>">
                        <?= htmlspecialchars($etat) ?>
                    </span>
                    <span class="plaque-immat"><?= htmlspecialchars($vehicule['Immatriculation'] ?? '') ?></span>
                </div>

                <div class="nom-vehicule">
                    <?= htmlspecialchars(($vehicule['Marque'] ?? '') . ' ' . ($vehicule['Modele'] ?? '')) ?>
                </div>

                <div class="prix-bleu">
                    <?= htmlspecialchars($vehicule['Prix'] ?? '') ?> € <small>/ jour</small>
                </div>

                <div class="ligne-separateur"></div>

                <p class="info-voiture">
                    <strong>Kilométrage :</strong> <?= htmlspecialchars($vehicule['Km'] ?? '') ?> km
                </p>

                <div class="details-techniques">
                    <?php if (($vehicule['Type'] ?? '') === 'Voiture'): ?>
                        <p class="info-voiture"><strong>Places :</strong>       <?= htmlspecialchars($vehicule['Divers1'] ?? 'N/A') ?></p>
                        <p class="info-voiture"><strong>Climatisation :</strong><?= htmlspecialchars($vehicule['Divers2'] ?? 'N/A') ?></p>

                    <?php elseif (($vehicule['Type'] ?? '') === 'Moto'): ?>
                        <p class="info-voiture"><strong>Cylindrée :</strong> <?= htmlspecialchars($vehicule['Divers1'] ?? 'N/A') ?> cc</p>
                        <p class="info-voiture"><strong>Permis :</strong>    <?= htmlspecialchars($vehicule['Divers2'] ?? 'N/A') ?></p>

                    <?php else: ?>
                        <p class="info-voiture"><strong>Longueur :</strong>   <?= htmlspecialchars($vehicule['Divers1'] ?? 'N/A') ?> m</p>
                        <p class="info-voiture"><strong>Couchages :</strong>  <?= htmlspecialchars($vehicule['Divers2'] ?? 'N/A') ?></p>
                    <?php endif; ?>
                </div>

            </div>
        <?php endforeach; ?>
    </div>
</section>

</body>
</html>
