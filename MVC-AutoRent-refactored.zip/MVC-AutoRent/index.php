<?php
declare(strict_types=1);

require_once __DIR__ . '/router/Router.php';
require_once __DIR__ . '/controllers/VehicleController.php';

$router = new Router();

// Routes GET
$router->get('/', function () {
    $controller = new VehicleController();
    $controller->index();
});

// Routes POST
$router->post('/', function () {
    $controller = new VehicleController();
    $controller->importCsv();
});

$router->dispatch();
